#config file containing credentials for rds mysql instance
db_username = "admin"
db_password = "Password123"
db_name = "mysql"
